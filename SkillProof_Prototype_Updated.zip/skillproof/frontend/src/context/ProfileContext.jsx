import React, { createContext, useContext, useState, useEffect } from 'react';
import { getDemoProfile, analyzeProfile, matchOpportunities } from '../api/client';

const ProfileContext = createContext(null);

export function ProfileProvider({ children }) {
  const [currentProfile, setCurrentProfile] = useState(null);
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState('');
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('profile'); // 'profile', 'matches', 'org'

  // Load demo profile on initial boot if desired, or let user click
  const loadDemo = async () => {
    try {
      setLoading(true);
      setError(null);
      setLoadingStage('Loading pre-cached verified student profile...');
      
      const profile = await getDemoProfile();
      setCurrentProfile(profile);
      
      setLoadingStage('Computing opportunity matches and gap analysis...');
      const matchResults = await matchOpportunities({
        student_id: profile.id,
        skills: profile.skills,
        min_score: 0.0
      });
      setMatches(matchResults);
      setActiveTab('profile');
    } catch (err) {
      console.error('Failed to load demo profile:', err);
      setError(err?.response?.data?.detail || 'Failed to connect to backend server. Make sure FastAPI is running on port 8000.');
    } finally {
      setLoading(false);
      setLoadingStage('');
    }
  };

  const handleAnalyzeProfile = async (githubUsername, resumeText, manualSkills) => {
    try {
      setLoading(true);
      setError(null);
      setLoadingStage('Querying GitHub API for repositories and README files...');
      
      // Artificial delay simulation for UX feedback stages
      const stageTimer1 = setTimeout(() => {
        setLoadingStage('Extracting skills from available repository and project evidence...');
      }, 1500);

      const stageTimer2 = setTimeout(() => {
        setLoadingStage('Normalizing canonical skills and persisting verified evidence...');
      }, 3500);

      const profile = await analyzeProfile({
        github_username: githubUsername,
        resume_text: resumeText,
        manual_skills: manualSkills
      });

      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);

      setCurrentProfile(profile);
      
      setLoadingStage('Matching profile against opportunities and generating gap actions...');
      const matchResults = await matchOpportunities({
        student_id: profile.id,
        skills: profile.skills,
        min_score: 0.0
      });
      setMatches(matchResults);
      setActiveTab('profile');
    } catch (err) {
      console.error('Profile analysis failed:', err);
      const detail = err?.response?.data?.detail || err?.message || 'Error analyzing profile. Please check username or try demo.';
      setError(detail);
    } finally {
      setLoading(false);
      setLoadingStage('');
    }
  };

  const refreshMatches = async (roleType = null, minScore = 0.0) => {
    if (!currentProfile) return;
    try {
      setLoading(true);
      const matchResults = await matchOpportunities({
        student_id: currentProfile.id,
        skills: currentProfile.skills,
        role_type: roleType,
        min_score: minScore
      });
      setMatches(matchResults);
    } catch (err) {
      console.error('Failed to refresh matches:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ProfileContext.Provider
      value={{
        currentProfile,
        setCurrentProfile,
        matches,
        setMatches,
        loading,
        loadingStage,
        error,
        setError,
        activeTab,
        setActiveTab,
        loadDemo,
        handleAnalyzeProfile,
        refreshMatches,
      }}
    >
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error('useProfile must be used within a ProfileProvider');
  }
  return context;
}


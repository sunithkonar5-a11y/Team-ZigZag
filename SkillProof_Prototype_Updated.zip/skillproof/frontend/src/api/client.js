import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 45000,
});

/**
 * Fetch pre-cached rich demo student profile
 */
export async function getDemoProfile() {
  const response = await apiClient.get('/demo-profile');
  return response.data;
}

/**
 * Analyze GitHub profile and/or resume text
 * @param {Object} data { github_username, resume_text, manual_skills }
 */
export async function analyzeProfile(data) {
  const response = await apiClient.post('/analyze-profile', data);
  return response.data;
}

/**
 * Compute matches for a student profile against opportunities
 * @param {Object} data { student_id, skills, role_type, min_score }
 */
export async function matchOpportunities(data) {
  const response = await apiClient.post('/match', data);
  return response.data;
}

/**
 * Fetch all seeded opportunities
 */
export async function getOpportunities() {
  const response = await apiClient.get('/opportunities');
  return response.data;
}

/**
 * Match and rank candidate students for an organization role
 * @param {Object} data { opportunity_id, role_title, role_description, required_skills, preferred_skills, min_score }
 */
export async function orgMatch(data) {
  const response = await apiClient.post('/org-match', data);
  return response.data;
}

/**
 * Find complementary peers who cover gaps (P1)
 * @param {Object} data { student_id, opportunity_id, target_skills }
 */
export async function getTeammates(data) {
  const response = await apiClient.post('/teammates', data);
  return response.data;
}

